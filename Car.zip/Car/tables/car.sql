create table car(
carId int primary key auto_increment, 
carName varchar(50), 
carManufactureName varchar(50),
carModel varchar(30),
carManufactoringYear date,
carColor varchar(20)
    );