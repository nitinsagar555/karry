create table user(
id int primary key auto_increment,
userName varchar(30),
password varchar(50)
)